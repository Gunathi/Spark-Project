# Databricks notebook source
# DBTITLE 1,Import all the necessary libraries
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,create the DataFrame
df = spark.read.format("csv").load("/FileStore/tables/googleplaystore.csv", sep=",", header='true', escape='"', inferschema="true")
display(df)

# COMMAND ----------

# DBTITLE 1,no of rows
df.count()

# COMMAND ----------

# DBTITLE 1,just get the first row
df.show(1)

# COMMAND ----------

# DBTITLE 1,Get the schema of the table
df.printSchema()

# COMMAND ----------

# DBTITLE 1,Data Cleaning
 # Drop unused columns
 df = df.drop("size", "content Rating", "Last Updated", "Android Ver", "Current Ver")
 display(df)

# COMMAND ----------

df.printSchema()

# COMMAND ----------

# DBTITLE 1,change column data type
df = df.withColumn("Reviews", col("Reviews"). cast(IntegerType()))
df.printSchema()

# COMMAND ----------

# DBTITLE 1,Remove unnecessary symbols in data
df = df.withColumn("Installs", regexp_replace(col("Installs"),"[^0-9]","")).withColumn("Price", regexp_replace(col("Price"), "[$]", ""))
display(df)
df.printSchema()

# COMMAND ----------

# DBTITLE 1,convert data type of some columns
df = df.withColumn("Installs", col("Installs").cast(IntegerType())).withColumn("Price", col("Price").cast(IntegerType()))
df.printSchema()

# COMMAND ----------

display(df)

# COMMAND ----------

# DBTITLE 1,remove null values
df = df.dropna()
display(df)

# COMMAND ----------

# DBTITLE 1,Create Temporary View
df.createOrReplaceTempView("apps")

# COMMAND ----------

# MAGIC %sql select * from apps

# COMMAND ----------

# DBTITLE 1,Find out top 10 reviewed apps
# MAGIC %sql
# MAGIC select App, sum(Reviews) as sum_rew from apps
# MAGIC group by App
# MAGIC order by 2 Desc
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,Top 10 installed apps
# MAGIC %sql
# MAGIC select App, Type, sum(Installs) as sum_installs from apps
# MAGIC group by 1,2
# MAGIC order by 3 desc 
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,Category Wise distribution of the installed apps
# MAGIC %sql
# MAGIC select Category, sum(Installs) from apps
# MAGIC group by 1
# MAGIC order by 2 desc

# COMMAND ----------

# DBTITLE 1,Top paid apps
# MAGIC %sql
# MAGIC select App, Type, sum(Price) from apps
# MAGIC where Type= "Paid"
# MAGIC group by 1,2
# MAGIC order by 3 desc
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,Which genre apps sold at a high Price
# MAGIC %sql
# MAGIC select App, Genres, sum(price) from apps
# MAGIC group by 1,2
# MAGIC order by 3 desc
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,Identify the top-performing apps in each category based on user reviews and ratings
from pyspark.sql.window import Window
from pyspark.sql.functions import col, row_number

# Calculate the average rating for each app
avg_rating_df = df.groupBy("App", "Category").agg(
    avg("Rating").alias("AvgRating"),
    expr("sum(Reviews)").alias("TotalReviews")  # Sum up reviews for normalization
)

display(avg_rating_df)

# COMMAND ----------

# Performance Score = AvgRating * log(TotalReviews + 1)
from pyspark.sql.functions import log

performance_df = avg_rating_df.withColumn(
    "PerformanceScore", col("AvgRating") * log(col("TotalReviews") + 1)
)

display(performance_df)

# COMMAND ----------

# Define a window for ranking within each category
category_window = Window.partitionBy("Category").orderBy(col("PerformanceScore").desc())

# Rank apps within each category
ranked_df = performance_df.withColumn("Rank", row_number().over(category_window))
display(ranked_df)

# COMMAND ----------

ranked_df.createOrReplaceTempView("ranked_apps")

# COMMAND ----------

# MAGIC %sql
# MAGIC select App,PerformanceScore from ranked_apps
# MAGIC limit 10

# COMMAND ----------

# DBTITLE 1,User Engagement Analysis
# MAGIC %sql
# MAGIC select App, avg(Rating) as avg_rating from apps
# MAGIC group by 1
# MAGIC having avg(Rating) < 3.0

# COMMAND ----------

# Remove apps where the average rating is 3.0 or higher to focus on poorly-rated apps. Because for app developers or analysts, poorly-rated apps often represent areas with the most potential for improvement.

poor_df = df.filter(col("Rating") < 3.0)
display(poor_df)

# COMMAND ----------

# Compute engagement metrics (Reviews per Download)

engagement_df = poor_df.withColumn(
    "ReviewsPerDownload",
    when(col("Installs") > 0, col("Reviews") / col("Installs")).otherwise(lit(0))
)

# COMMAND ----------

display(engagement_df)

# COMMAND ----------

windowSpec = Window.partitionBy("Category").orderBy(col("ReviewsPerDownload").desc())

ranked_df = engagement_df.withColumn("Rank", rank().over(windowSpec))

top_apps_df = ranked_df.filter(col("Rank") <= 5)

# display(top_apps_df)
top_apps_df.select("App", "Category", "Rating", "Reviews", "ReviewsPerDownload", "Rank").show()

# COMMAND ----------


